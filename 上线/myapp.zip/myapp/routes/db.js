module.exports = {
  mysql: {
    host: "localhost",
    user: "root",
    password: "123456",
    database: "stitp",
    port: "3306"
  }
}